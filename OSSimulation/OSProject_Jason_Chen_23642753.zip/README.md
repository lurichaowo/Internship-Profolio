# Jason Chen 23642753
## Instructions
### ```bash .... ``` means to run in terminal
Will need a g++ compiler that supports c++11
Start with make clean to make sure no stray, leftover files
```bash
make clean
```
Then do a make all into  make run
```bash
make all
make run
```
To restart program to do another test:
ctrl + z to stop program into make run again
```bash
make run
```
When done testing, do a make clean
```bash
make clean
```
